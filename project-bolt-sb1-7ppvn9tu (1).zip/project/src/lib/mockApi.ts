import { AnalysisResult, AnalysisHistory, User, AnalysisFilter } from '../types';

// Simulated delay for API calls
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Generate random truth score between 0-100
const generateTruthScore = (url: string): number => {
  // Use URL to generate a deterministic but seemingly random score
  const seed = url.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return Math.max(5, Math.min(98, (seed % 100)));
};

// Generate flag data based on truth score
const generateFlags = (url: string, truthScore: number) => {
  const flags = [];
  
  if (truthScore < 70) {
    flags.push({
      type: 'biasedLanguage' as const,
      severity: truthScore < 40 ? 'high' as const : 'medium' as const,
      description: 'Content contains emotionally charged language designed to influence opinion.',
    });
  }
  
  if (truthScore < 60) {
    flags.push({
      type: 'factualAccuracy' as const,
      severity: truthScore < 30 ? 'high' as const : 'medium' as const,
      description: 'Several claims contradict established sources or contain outdated information.',
    });
  }
  
  if (truthScore < 50) {
    flags.push({
      type: 'sourceCredibility' as const,
      severity: 'high' as const,
      description: 'Source has a history of publishing unverified or false information.',
    });
  }
  
  if (truthScore < 40) {
    flags.push({
      type: 'imageManipulation' as const,
      severity: 'high' as const,
      description: 'Images appear to be digitally altered or presented out of context.',
    });
  }
  
  return flags;
};

export const analyzeUrl = async (url: string): Promise<AnalysisResult> => {
  await delay(2000); // Simulate API processing time
  
  const truthScore = generateTruthScore(url);
  const domain = new URL(url).hostname;
  
  let status: 'verified' | 'refuted' | 'mixed';
  if (truthScore >= 75) status = 'verified';
  else if (truthScore <= 35) status = 'refuted';
  else status = 'mixed';
  
  // Generate categories with values that sum to the truth score
  const biasedLanguage = Math.min(100, Math.max(10, 100 - (truthScore * 0.4 + Math.random() * 20)));
  const sourceCredibility = Math.min(100, Math.max(10, truthScore * 0.8 + Math.random() * 10));
  const factualAccuracy = Math.min(100, Math.max(10, truthScore * 0.9 + Math.random() * 15));
  const imageManipulation = Math.min(100, Math.max(10, 100 - (truthScore * 0.7 + Math.random() * 20)));
  
  // Generate personalized summary based on the URL and score
  const summaries = [
    `This content from ${domain} contains multiple misleading claims and should be viewed with skepticism.`,
    `While some information appears accurate, this article from ${domain} contains several biased statements.`,
    `Our analysis indicates this content from ${domain} is largely factual with minor issues.`,
    `The information from ${domain} has been verified against multiple credible sources and appears accurate.`
  ];
  
  const summaryIndex = Math.min(3, Math.floor(truthScore / 25));
  
  return {
    id: `analysis-${Date.now()}`,
    url,
    title: `Analysis of content from ${domain}`,
    domain,
    truthScore,
    status,
    createdAt: new Date().toISOString(),
    categories: {
      biasedLanguage,
      sourceCredibility,
      factualAccuracy,
      imageManipulation
    },
    flags: generateFlags(url, truthScore),
    summary: summaries[summaryIndex]
  };
};

export const getUserHistory = async (userId: string, filters?: AnalysisFilter): Promise<AnalysisHistory> => {
  await delay(1000); // Simulate API call
  
  // Generate 10 random analyses
  const analyses = Array.from({ length: 10 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    const fakeUrls = [
      'https://www.newssite.com/article/politics-2023',
      'https://www.technews.org/latest/ai-breakthrough',
      'https://www.scienceblog.com/discovery/health',
      'https://www.dailyreporter.net/world/events',
      'https://www.factstream.com/reports/economy'
    ];
    
    return analyzeUrl(fakeUrls[i % fakeUrls.length]);
  });
  
  // Resolve all the promises from analyzeUrl
  const recentAnalyses = await Promise.all(analyses);
  
  // Apply filters if provided
  let filteredAnalyses = recentAnalyses;
  if (filters) {
    if (filters.status) {
      filteredAnalyses = filteredAnalyses.filter(a => a.status === filters.status);
    }
    if (filters.minScore !== undefined) {
      filteredAnalyses = filteredAnalyses.filter(a => a.truthScore >= (filters.minScore || 0));
    }
    if (filters.maxScore !== undefined) {
      filteredAnalyses = filteredAnalyses.filter(a => a.truthScore <= (filters.maxScore || 100));
    }
  }
  
  const total = filteredAnalyses.length;
  const averageTruthScore = total > 0 
    ? Math.round(filteredAnalyses.reduce((sum, a) => sum + a.truthScore, 0) / total) 
    : 0;
  
  const distribution = {
    verified: filteredAnalyses.filter(a => a.status === 'verified').length,
    refuted: filteredAnalyses.filter(a => a.status === 'refuted').length,
    mixed: filteredAnalyses.filter(a => a.status === 'mixed').length
  };
  
  return {
    total,
    averageTruthScore,
    distribution,
    recentAnalyses: filteredAnalyses
  };
};

export const getCurrentUser = async (): Promise<User | null> => {
  // Check local storage for logged in state (in a real app, would verify with backend)
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  
  if (!isLoggedIn) {
    return null;
  }
  
  await delay(500);
  
  return {
    id: 'user-1',
    name: 'Jane Smith',
    email: 'jane.smith@example.com',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
    createdAt: '2023-01-15T08:30:00.000Z'
  };
};

export const loginUser = async (email: string, password: string): Promise<User> => {
  await delay(1000);
  
  // Simple validation
  if (!email || !password) {
    throw new Error('Email and password are required');
  }
  
  // In a real app, this would validate against a backend
  localStorage.setItem('isLoggedIn', 'true');
  
  return {
    id: 'user-1',
    name: 'Jane Smith',
    email,
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
    createdAt: '2023-01-15T08:30:00.000Z'
  };
};

export const registerUser = async (name: string, email: string, password: string): Promise<User> => {
  await delay(1500);
  
  // Simple validation
  if (!name || !email || !password) {
    throw new Error('All fields are required');
  }
  
  // In a real app, this would register with a backend
  localStorage.setItem('isLoggedIn', 'true');
  
  return {
    id: 'user-1',
    name,
    email,
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
    createdAt: new Date().toISOString()
  };
};

export const logoutUser = async (): Promise<void> => {
  await delay(500);
  localStorage.removeItem('isLoggedIn');
};